#! /bin/bash

testAPI.x mooringSystem.m positions.txt
